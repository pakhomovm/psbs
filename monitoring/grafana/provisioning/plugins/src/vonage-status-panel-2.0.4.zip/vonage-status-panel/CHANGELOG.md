# Changelog

## v2.0.0

Migrating Status Panel from Angular to react. This release includes automatic migrations for Angular panels, but please make sure to have backups and test this migrations in a staging environment first as we can not guarantee that they will all be translated properly.

## 1.0.0 (Unreleased)

Initial release.
